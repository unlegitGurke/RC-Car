![top](top.png)
![bottom](bottom.png)

This is the 1.0.0 initial batch. The diagonal sensor is 0.1" too far back, so
the pins on that sensor need re-bending.
